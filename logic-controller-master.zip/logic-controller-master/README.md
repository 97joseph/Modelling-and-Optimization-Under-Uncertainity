# logic-controller
Related Paper: A Design Method of Fuzzy Logic Controller by Using Q Learning Algorithm  

If there are any questions, please contact me with inksci@qq.com  
Thank you for your visit!  

There is an experiment with success rate of 100% for all the 1,000,000 tests, and [click here](https://github.com/inksci/logic-controller/blob/master/results/Test%20for%20fuzzy%20logic%20controller.ipynb) please. 
